"""
✅ ЧТО ТЕСТ ДЕЛАЕТ: Тестирует заявки на роль преподавателя и их одобрение Админом.
"""
import pytest
import uuid


class TestProfessorApplication:
    @staticmethod
    def test_submit_application_success(student_client):
        """
        🎯 ОЖИДАЕМЫЙ РЕЗУЛЬТАТ: Заявка создана (201).
        """
        res = student_client.post("/api/v1/users/submit-professor-application", json={
            "name": "Иван",
            "surname": "Иванов"
        })
        assert res.status_code == 201
        assert "id" in res.json()

    @staticmethod
    def test_get_my_applications(student_client):
        """
        ✅ ЧТО ТЕСТ ДЕЛАЕТ: Студент подает заявку и проверяет список своих заявок.
        🎯 ОЖИДАЕМЫЙ РЕЗУЛЬТАТ: Список содержит хотя бы одну заявку (200).
        """
        student_client.post("/api/v1/users/submit-professor-application", json={
            "name": "Пётр", "surname": "Петров"
        })
        res = student_client.get("/api/v1/users/get-my-applications")
        assert res.status_code == 200
        assert len(res.json()) > 0

    @staticmethod
    def test_approve_application_changes_role(admin_client, student_client):
        """
        ✅ ЧТО ТЕСТ ДЕЛАЕТ (полный сценарий через API):
        1. Студент подаёт заявку и выходит.
        2. Админ одобряет заявку через /change-application-status.
        3. Админ меняет роль через /change-role.
        4. Админ выходит.
        5. Студент заходит заново и проверяет, что стал профессором.

        🎯 ОЖИДАЕМЫЙ РЕЗУЛЬТАТ: Роль студента стала 'professor'.
        """
        # ========== ШАГ 1: Студент подаёт заявку ==========
        submit_res = student_client.post("/api/v1/users/submit-professor-application", json={
            "name": "Сергей", "surname": "Сергеев"
        })
        assert submit_res.status_code == 201, f"Ошибка подачи заявки: {submit_res.text}"
        application_id = submit_res.json()["id"]

        student_profile = student_client.get("/api/v1/users/profile").json()
        student_id = student_profile["id"]
        student_nickname = student_profile["nickname"]

        # Студент выходит
        student_client.get("/api/v1/auth/logout")

        # ========== ШАГ 2: Админ одобряет заявку ==========
        approve_res = admin_client.put("/api/v1/users/change-application-status", json={
            "application_id": application_id,
            "user_id": student_id,
            "status": "approved",
            "admin_comment": "Approved by QA test"
        })
        assert approve_res.status_code in [200, 204], \
            f"Ошибка одобрения заявки: {approve_res.status_code} {approve_res.text}"

        # ========== ШАГ 3: Админ меняет роль через /change-role ==========
        change_role_res = admin_client.put("/api/v1/users/change-role", json={
            "id": student_id,
            "role": "professor"  # ← В нижнем регистре, как в OpenAPI!
        })
        assert change_role_res.status_code == 204, \
            f"Ошибка смены роли: {change_role_res.status_code} {change_role_res.text}"

        # ========== ШАГ 4: Админ выходит ==========
        admin_client.get("/api/v1/auth/logout")

        # ========== ШАГ 5: Студент заходит заново и проверяет роль ==========
        login_res = student_client.post("/api/v1/auth/login", json={
            "nickname": student_nickname,
            "password": "StrongPassword123!"
        })
        assert login_res.status_code == 200, f"Ошибка входа студента: {login_res.text}"

        new_profile = student_client.get("/api/v1/users/profile").json()
        assert new_profile["role"] == "professor", \
            f"Роль не изменилась! Текущая: {new_profile['role']}"

        print("🎉 Тест пройден: студент стал преподавателем через полный API-сценарий!")